"use strict"

{
    let a =0;
    // let a = 4;
    // let a = 3;
    let b =3;
    if(a<b){
        console.log(b + " es mayor que " +a);
    }else if (a>b){
        console.log(a + " es mayor que " + b);
    }else{
        console.log(a + " es igual que " +b);
    }
}