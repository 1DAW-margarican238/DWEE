"use strict"
{
    //Programa una función para convertir números de base binaria a decimal y viceversa, pe. miFuncion(100,2) devolverá 4 base 10

// no lo se como hacerlo

 function myFunction(num, base){
    if(base == 2) {
        let decimal = 0;
        let potencia = 1;
    
    
    
    
    }
 }
    console.log(myFunction(100, 2));
    console.log(myFunction(4, 10));
}